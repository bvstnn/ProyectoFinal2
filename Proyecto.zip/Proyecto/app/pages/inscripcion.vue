<template>
    <main class="min-h-screen bg-slate-950 py-12 px-4 flex items-center justify-center">

        <div v-if="eventoSeleccionado"
            class="w-full max-w-5xl bg-slate-900 rounded-2xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col md:flex-row">
            <div class="w-full md:w-5/12 bg-slate-800 relative">
                <img :src="eventoSeleccionado.imagen" :alt="eventoSeleccionado.titulo"
                    class="absolute inset-0 w-full h-full object-cover opacity-40 mix-blend-overlay">
                <div class="relative z-10 p-10 h-full flex flex-col justify-center">
                    <div
                        class="inline-block px-3 py-1 bg-purple-500/20 border border-purple-500/50 rounded-full text-purple-300 text-xs font-bold mb-4 w-max">
                        INSCRIPCIÓN ABIERTA
                    </div>
                    <h1 class="text-3xl md:text-4xl font-bold font-orbitron text-white mb-4 leading-tight">
                        {{ eventoSeleccionado.titulo }}
                    </h1>
                    <div class="space-y-4 text-slate-300 mt-6 border-t border-slate-700/50 pt-6">
                        <p class="flex items-center gap-3">
                            <strong class="text-purple-400">Fecha:</strong>
                            {{ new Date(eventoSeleccionado.fecha).toLocaleDateString('es-CL') }}
                        </p>
                        <p class="flex items-center gap-3">
                            <strong class="text-purple-400">Lugar:</strong>
                            {{ eventoSeleccionado.lugar }}
                        </p>
                    </div>
                </div>
            </div>

            <div class="w-full md:w-7/12 p-10 lg:p-14 bg-slate-900">
                <h2 class="text-2xl font-bold text-white mb-2">Reserva tu cupo</h2>
                <p class="text-slate-400 text-sm mb-8">Completa tus datos para confirmar tu asistencia.</p>

                <form @submit.prevent="inscribirUsuario" class="space-y-5">
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                        <div>
                            <label
                                class="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Nombre</label>
                            <input v-model="formulario.nombre" type="text" required
                                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-purple-500">
                        </div>
                        <div>
                            <label
                                class="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Apellido</label>
                            <input v-model="formulario.apellido" type="text" required
                                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-purple-500">
                        </div>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Correo
                            Electrónico</label>
                        <input v-model="formulario.email" type="email" required
                            class="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-purple-500">
                    </div>

                    <div v-if="inscripcionExitosa"
                        class="text-emerald-400 bg-emerald-500/10 px-4 py-3 rounded-lg text-sm">
                        ¡Inscripción confirmada!
                    </div>

                    <button type="submit"
                        class="w-full mt-4 bg-purple-600 hover:bg-purple-500 text-white font-bold py-3.5 px-4 rounded-lg transition-all">
                        Confirmar Inscripción
                    </button>
                </form>
            </div>
        </div>

        <div v-else class="text-center text-slate-400">
            <h2 class="text-2xl font-bold text-white mb-2">No has seleccionado ningún evento</h2>
            <p class="mb-6">Vuelve al inicio y haz clic en Inscribirse en alguna de las tarjetas.</p>
            <NuxtLink to="/"
                class="bg-purple-600 hover:bg-purple-500 text-white font-bold py-2 px-4 rounded transition-all">
                Volver a la cartelera
            </NuxtLink>
        </div>

    </main>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useState } from '#app'

// Leemos la memoria global
const eventoSeleccionado = useState<any>('eventoActual')

const formulario = ref({
    nombre: '',
    apellido: '',
    email: ''
})

const inscripcionExitosa = ref(false)

const inscribirUsuario = () => {
    inscripcionExitosa.value = true
    formulario.value = { nombre: '', apellido: '', email: '' }
    setTimeout(() => { inscripcionExitosa.value = false }, 4000)
}
</script>