<script setup lang="ts">

import type { Evento } from '~/types/evento'
// Consumimos tu endpoint directamente para obtener el arreglo de eventos
const { data: eventos, pending, error, refresh } = await useFetch<Evento[]>('/api/eventos/evento')

</script>
<template>
    <main class="min-h-screen bg-slate-950 p-6 md:p-12">
        <div class="max-w-6xl mx-auto">

            <!-- Encabezado simple -->
            <h1 class="text-3xl md:text-4xl font-bold text-white mb-8 border-b border-purple-500/50 pb-4">
                Próximos Eventos
            </h1>

            <!-- Grilla iterativa -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">

                <!-- Iteramos el componente Card automáticamente -->
                <EventoCard v-for="evento in eventos" :evento="evento" />

            </div>

        </div>
    </main>
</template>
