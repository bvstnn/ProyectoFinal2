export default defineEventHandler(async (event) => {
    const body = await readBody(event)
    const { titulo, fecha, lugar, imagen, valor } = body
    const tituloNormalizado = typeof titulo === 'string' ? titulo.trim() : '' 
    const lugarNormalizado = typeof lugar === 'string' ? lugar.trim() : '' 
    const evento = await prisma.evento.create({ data: { titulo: tituloNormalizado, fecha, lugar: lugarNormalizado, imagen, valor } })
    return {ok: true, evento}
})
  