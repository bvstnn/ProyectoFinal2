<script setup lang="ts">
import type { Inscripcion } from '~/types/Inscripcion'
const { data: inscripciones, pending, error, refresh } = await useFetch<Inscripcion[]>('/api/inscripciones') 
</script>

<template>
  <main class="min-h-screen bg-slate-950 py-12 px-4 flex items-center justify-center">

    <div
      class="w-full max-w-5xl bg-slate-900 rounded-2xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col md:flex-row">

      <div class="w-full md:w-5/12 bg-slate-800 relative">
        <img :src="eventoMock.imagen" :alt="eventoMock.titulo"
          class="absolute inset-0 w-full h-full object-cover opacity-40 mix-blend-overlay">
        <div class="relative z-10 p-10 h-full flex flex-col justify-center">
          <div
            class="inline-block px-3 py-1 bg-purple-500/20 border border-purple-500/50 rounded-full text-purple-300 text-xs font-bold mb-4 w-max">
            INSCRIPCIÓN ABIERTA
          </div>
          <h1 class="text-3xl md:text-4xl font-bold font-orbitron text-white mb-4 leading-tight">
            {{ eventoMock.titulo }}
          </h1>
          <div class="space-y-4 text-slate-300 mt-6 border-t border-slate-700/50 pt-6">
            <p class="flex items-center gap-3">
              <i class="fa-solid fa-calendar text-purple-400"></i>
              {{ new Date(eventoMock.fecha).toLocaleDateString('es-CL') }}
            </p>
            <p class="flex items-center gap-3">
              <i class="fa-solid fa-location-dot text-purple-400"></i>
              {{ eventoMock.lugar }}
            </p>
            <p class="flex items-center gap-3">
              <i class="fa-solid fa-ticket text-purple-400"></i>
              Valor: {{ eventoMock.valor === 0 ? 'Entrada Liberada' : '$' + eventoMock.valor.toLocaleString('es-CL') }}
            </p>
          </div>
        </div>
      </div>

      <div class="w-full md:w-7/12 p-10 lg:p-14 bg-slate-900">
        <h2 class="text-2xl font-bold text-white mb-2">Reserva tu cupo</h2>
        <p class="text-slate-400 text-sm mb-8">Completa tus datos para confirmar tu asistencia al evento.</p>

        <form @submit.prevent="inscribirUsuario" class="space-y-5">

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div class="relative">
              <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Nombre</label>
              <div class="relative">
                <i class="fa-solid fa-user absolute left-4 top-1/2 -translate-y-1/2 text-slate-500"></i>
                <input v-model="formulario.nombre" type="text" required
                  class="w-full bg-slate-950 border border-slate-800 rounded-lg pl-11 pr-4 py-3 text-white placeholder-slate-600 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-all"
                  placeholder="Juan">
              </div>
            </div>

            <div class="relative">
              <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Apellido</label>
              <div class="relative">
                <i class="fa-solid fa-signature absolute left-4 top-1/2 -translate-y-1/2 text-slate-500"></i>
                <input v-model="formulario.apellido" type="text" required
                  class="w-full bg-slate-950 border border-slate-800 rounded-lg pl-11 pr-4 py-3 text-white placeholder-slate-600 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-all"
                  placeholder="Pérez">
              </div>
            </div>
          </div>

          <div class="relative">
            <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Correo
              Electrónico</label>
            <div class="relative">
              <i class="fa-solid fa-envelope absolute left-4 top-1/2 -translate-y-1/2 text-slate-500"></i>
              <input v-model="formulario.email" type="email" required
                class="w-full bg-slate-950 border border-slate-800 rounded-lg pl-11 pr-4 py-3 text-white placeholder-slate-600 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-all"
                placeholder="juan.perez@ejemplo.com">
            </div>
          </div>

          <div v-if="inscripcionExitosa"
            class="flex items-center gap-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-4 py-3 rounded-lg">
            <i class="fa-solid fa-circle-check"></i>
            <span class="text-sm">¡Inscripción confirmada exitosamente!</span>
          </div>

          <button type="submit"
            class="w-full mt-4 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold py-3.5 px-4 rounded-lg shadow-[0_0_20px_rgba(147,51,234,0.2)] hover:shadow-[0_0_25px_rgba(147,51,234,0.4)] transition-all transform hover:-translate-y-0.5">
            Confirmar Inscripción
          </button>
        </form>

      </div>
    </div>
  </main>
</template>

<script setup lang="ts">
  import type { Script } from 'node:vm'
import { ref } from 'vue'

const eventoMock = ref({
  id: 1,
  titulo: 'Torneo Nacional E-Sports 2026',
  fecha: '2026-08-15T18:00:00',
  lugar: 'Arena Central, Santiago',
  imagen: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  valor: 15000
})

const formulario = ref({
  nombre: '',
  apellido: '',
  email: ''
})

const inscripcionExitosa = ref(false)

const inscribirUsuario = async () => {
  console.log('Enviando datos:', formulario.value)
  inscripcionExitosa.value = true
  
  formulario.value = { nombre: '', apellido: '', email: '' }

  setTimeout(() => {
    inscripcionExitosa.value = false
  }, 4000)
}
</script>