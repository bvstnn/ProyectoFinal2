<script setup lang="ts">
import type { Evento } from '~/types/Evento'
const { data: eventos, pending, error, refresh } = await useFetch<Evento[]>('/api/eventos') 
</script>

<template>
  <main class="min-h-screen bg-slate-950 font-urbanist text-slate-100 pb-20">

    <section class="max-w-7xl mx-auto px-6 pt-20 pb-16 text-center relative overflow-hidden">
      <div class="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-64 bg-purple-900/20 blur-[120px] z-0 rounded-full">
      </div>

      <div class="relative z-10">
        <div
          class="inline-flex items-center gap-2 px-3 py-1 mb-6 rounded-full bg-indigo-950/70 border border-indigo-900">
          <span class="w-2 h-2 rounded-full bg-fuchsia-500 animate-pulse"></span>
          <span class="text-xs font-medium text-slate-300 uppercase tracking-widest">Prototipo UI</span>
        </div>
        <h1 class="font-orbitron text-5xl md:text-6xl font-black mb-6">
          Explora los Próximos <span class="text-fuchsia-500">Eventos</span>
        </h1>
        <p class="text-lg text-slate-400 max-w-2xl mx-auto">
          Conéctate con la comunidad. Encuentra tu próxima experiencia gamer, concierto neón o meetup tech.
        </p>
      </div>
    </section>

    <section class="max-w-7xl mx-auto px-6">

      <div class="flex items-center justify-between mb-10 border-b border-slate-800 pb-4">
        <h2 class="font-orbitron text-3xl font-bold border-l-4 border-fuchsia-500 pl-4">Feed de <span
            class="text-fuchsia-500">Actividades</span></h2>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">

        <div v-for="evento in eventosMock" :key="evento.id"
          class="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden hover:border-purple-600 hover:shadow-[0_0_30px_rgba(88,28,135,0.4)] transition-all duration-300 group flex flex-col">

          <div class="h-56 overflow-hidden relative bg-slate-950 border-b border-slate-800">
            <img :src="evento.imagen" :alt="evento.titulo"
              class="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-110 transition-all duration-500">

            <div
              class="absolute top-4 right-4 bg-slate-900/90 backdrop-blur-sm border border-fuchsia-500/50 px-3 py-1 rounded-lg shadow-lg">
              <span class="text-fuchsia-400 font-bold font-orbitron">
                {{ evento.valor === 0 ? 'GRATIS' : '$' + evento.valor.toLocaleString('es-CL') }}
              </span>
            </div>
          </div>

          <div class="p-6 flex flex-col flex-grow">
            <h3
              class="font-orbitron text-xl font-bold text-slate-100 mb-4 group-hover:text-fuchsia-400 transition-colors line-clamp-2">
              {{ evento.titulo }}
            </h3>

            <div class="space-y-3 text-sm text-slate-400 mb-6 flex-grow">
              <p class="flex items-center gap-3">
                <i class="fa-solid fa-calendar text-purple-500 w-4"></i>
                {{ new Date(evento.fecha).toLocaleDateString('es-CL') }}
              </p>
              <p class="flex items-center gap-3">
                <i class="fa-solid fa-location-dot text-purple-500 w-4"></i>
                <span class="truncate">{{ evento.lugar }}</span>
              </p>
            </div>

            <button
              class="w-full py-3 rounded-xl border border-slate-700 bg-slate-800 text-slate-300 font-medium group-hover:border-transparent group-hover:bg-gradient-to-r group-hover:from-purple-700 group-hover:to-fuchsia-600 group-hover:text-white transition-all shadow-lg mt-auto">
              Ver Detalles
            </button>
          </div>

        </div>
      </div>

    </section>
  </main>
</template>

<script setup lang="ts">
import { ref } from 'vue'

// DATOS DE PRUEBA (MOCK DATA)
// Simula exactamente lo que te devolvería Prisma desde la BD
const eventosMock = ref([
  {
    id: 1,
    titulo: 'Torneo Nacional E-Sports 2026',
    fecha: '2026-08-15T18:00:00',
    lugar: 'Arena Central, Santiago',
    imagen: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    valor: 15000
  },
  {
    id: 2,
    titulo: 'Neon Nights: Synthwave Live',
    fecha: '2026-09-02T22:00:00',
    lugar: 'Teatro Caupolicán',
    imagen: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    valor: 25000
  },
  {
    id: 3,
    titulo: 'Tech & Code Meetup V Región',
    fecha: '2026-10-10T09:00:00',
    lugar: 'Cowork Viña del Mar',
    imagen: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    valor: 0
  }
])
</script>